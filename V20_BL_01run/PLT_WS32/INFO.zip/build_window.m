function window=build_window(ima,posx,posy,wsx,wsy,rx,ry)

[dimy,dimx]=size(ima);
if posx-rx<1 posx=1+rx; end                                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if posy-ry<1 posy=1+ry; end                                                % Make sure the intterogation window
if posx+rx>dimx posx=dimx-rx; end                                          % is inside the image pixels
if posy+ry>dimy posy=dimy-ry; end                                          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
bufwind=double(ima(posy-ry:posy+ry,posx-rx:posx+rx));                      % Extract the interrogation window
%figure(3), surf(bufwind), pause
bufmean=mean(mean(bufwind));                                               % Averaging the interrogation window
bufwind=(bufwind-bufmean);                                                 % Remove the mean value
covwind=sum(sum(bufwind.^2))/(wsx*wsy);                                    % 
window=bufwind/(sqrt(covwind)*(covwind~=0)+0.000001*(covwind==0));         % What's the reason???????????????   


% [wy,wx]=size(window);
% [y,x]=meshgrid(1:wsx,1:wsy);
% w=9*(4*abs(x/wx).^2-4*abs(x/wx)+1).*(4*abs(y/wy).^2-4*abs(y/wy)+1);
% window=window.*w;