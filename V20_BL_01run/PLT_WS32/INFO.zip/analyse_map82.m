function [peaks,sn]=analyse_map82(corrmap)
npeaks=3;
[wsy,wsx]=size(corrmap);
Cmean=mean(corrmap(:));
rx=floor((wsx-1)/2);
ry=floor((wsy-1)/2);

k=0; peakstot=zeros(wsy*wsx,1);
for j=2:wsy-1                                                              % Sort out the peaks
    for i=2:wsx-1
        cloc=corrmap(j-1:j+1,i-1:i+1); cpoint=cloc(2,2); cloc(2,2)=min(cloc(:));        % cpoint: center point; cloc(2,2):minimum value
        if cpoint>cloc %cpoint is a max
            k=k+1;
            peakstot(k)=cpoint;
        end
    end
end

peakssort=sort(peakstot,'descend');

peaks=zeros(npeaks,3);
for k=1:npeaks                                                             % Record the positions of first three peaks
    peaks(k,3)=peakssort(k);
    
    [y x]=find(corrmap==peakssort(k));
    if peaks(k,3)~=0                                                       % Continue if non-zero peak                                                     
        peaks(k,1)=x(1);                                                   % Store the location
        peaks(k,2)=y(1);                                                   % Store the location
    end
end

if peaks(2,3)~=0;
    sn=peaks(1,3)/peaks(2,3);                                              % Peak ration between 1st and 2nd peaks
else
    sn=20;
end
