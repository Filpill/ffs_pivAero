function [uregr] = regression_solve(U,X,Y)
%% build the A matrix
x=X(:); y=Y(:); u=U(:);
A=zeros(6);

A(1,2)=sum(x);
A(1,3)=sum(y);
A(1,4)=sum(x.*y);
A(1,5)=sum(x.^2);
A(1,6)=sum(y.^2);

A(2,3)=sum(x.*y);
A(2,4)=sum(x.^2.*y);
A(2,5)=sum(x.^3);
A(2,6)=sum(x.*y.^2);

A(3,4)=sum(x.*y.^2);
A(3,5)=sum(x.^2.*y);
A(3,6)=sum(y.^3);

A(4,5)=sum(x.^3.*y);
A(4,6)=sum(x.*y.^3);

A(5,6)=sum(x.^2.*y.^2);

A=A+A';

% diagonal
A(1,1)=length(x);
A(2,2)=sum(x.^2);
A(3,3)=sum(y.^2);
A(4,4)=sum(x.^2.*y.^2);
A(5,5)=sum(x.^4);
A(6,6)=sum(y.^4);

%% build the known term
f=zeros(6,1);
f(1)=sum(u);
f(2)=sum(x.*u);
f(3)=sum(y.*u);
f(4)=sum(x.*y.*u);
f(5)=sum(x.^2.*u);
f(6)=sum(y.^2.*u);

%% solution
C=A\f;
regr=C(1)+C(2)*X+C(3)*Y+C(4)*X.*Y+C(5)*X.^2+C(6)*Y.^2;
uregr=C(1);
% figure(2),clf,surf(X,Y,reshape(regr,size(X,1),size(X,2)))
end %end function

