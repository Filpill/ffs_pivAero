function [diff_displ_u,diff_displ_v]=build_diff(densepred,grdx,grdy,r)

% [rx ry]
% [grdx-rx grdx+rx]
% [grdy-ry grdy+ry]
% pause
[J,I,K]=size(densepred);
y0=grdy-r; if y0<1 y0=1; end
y1=grdy+r; if y1>J y1=J; end
x0=grdx-r; if x0<1 x0=1; end
x1=grdx+r; if x1>I x1=I; end
    
buf=densepred(y0:y1,x0:x1,1);
diff_displ_u=mean(buf(:));

buf=densepred(y0:y1,x0:x1,2);
diff_displ_v=mean(buf(:));