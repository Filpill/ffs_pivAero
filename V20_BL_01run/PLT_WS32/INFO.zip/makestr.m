function [zerostr]=makestr(counter)

zerostr='';
if (counter < 10)
   zerostr='000';
end;
if (counter >= 10) 
   zerostr='00';
end;
if (counter >= 100)
   zerostr='0';
end
if (counter >= 1000)
   zerostr='';
end
