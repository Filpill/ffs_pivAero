%routine that computes the outliers in the velocity field

%detection of the outliers
function [uf,vf] = outliers2(Thr,u,v,X,Y);

[Jf,If] = size(u);        % size of the displacement field
%MedianRes=zeros(Jf,If);   % initialise median residual
NormFluct=zeros(Jf,If,2); % initialise normalised fluctuations
b=1;                    % data-point neighborhood radius
eps=0.1;                % estimated measurement noise level (in pixel units)
Thr = 2;                % threshold
MedianMatrix= zeros(Jf,If,2);

for c=1:2 % loop over the two velocity components
    if c==1; VelComp=u; else VelComp=v; end;
    % loop over all the data points (excluding border)
    for io=1:If
        for jo=1:Jf
            if io==1
                if jo==1
                    Neigh=VelComp (jo:jo+b,io:io+b);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(2:end)];            % neighborhood excluding center-point
                elseif jo==Jf
                    Neigh=VelComp (jo-b:jo,io:io+b);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:b);NeighCol(b+2:end)];            % neighborhood excluding center-point
                else
                    Neigh=VelComp (jo-b:jo+b,io:io+b);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(b+1)*b);NeighCol((b+1)*b+2:end)];            % neighborhood excluding center-point
                end %if jo
            elseif io==If
                if jo==1
                    Neigh=VelComp (jo:jo+b,io-b:io);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(b+1)*b);NeighCol((b+1)*b+2:end)];            % neighborhood excluding center-point
                elseif jo==Jf
                    Neigh=VelComp (jo-b:jo,io-b:io);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(b+1)*b+b)];            % neighborhood excluding center-point
                else
                    Neigh=VelComp (jo-b:jo+b,io-b:io);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(2*b+1)*b+b);NeighCol((2*b+1)*b+b+2:end)];            % neighborhood excluding center-point
                end %if jo
            else % 2<=io<=If-1
                if jo==1
                    Neigh=VelComp (jo:jo+b,io-b:io+b);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(b+1)*b);NeighCol((b+1)*b+2:end)];            % neighborhood excluding center-point
                elseif jo==Jf
                    Neigh=VelComp (jo-b:jo,io-b:io+b);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(b+1)*b+b);NeighCol((b+1)*b+b+2:end)];            % neighborhood excluding center-point
                else % 2<=io<=If-1 & 2<=jo<=Jf-1
                    Neigh=VelComp (jo-b:jo+b,io-b:io+b);        % data neighborhood with center-point
                    NeighCol=Neigh(:);                      % in column format
                    NeighCol2=[NeighCol(1:(2*b+1)*b+b); NeighCol((2*b+1)*b+b+2:end)]; % neighborhood excluding center-point
                end %if jo

            end %if io
            
            Median=median(NeighCol2);               % median of the neighborhood
            MedianMatrix(jo,io,c) = Median;
            Fluct=VelComp(jo,io)-Median;              % fluctuation with respect to median
            Res=NeighCol2-Median;                   % residual: neighborhood fluctuatio w.r.t. median
            MedianRes=median(abs(Res));             % median (absolute) value of residual
            NormFluct(jo,io,c)=abs(Fluct/(MedianRes+eps)); % normalised fluctuation w.r.t. neighborhood median residal
            
        end; %for j0
    end; %for i0
end; %for c

info1=(sqrt(NormFluct(:,:,1).^2 + NormFluct(:,:,2).^2) > Thr);    % detection criterion
info1=info1(:);
Ibad=find(info1==1); % outliers
Igood=find(info1==0); % good vectores

Xcol=X(:);
Ycol=Y(:);
% coordinates of the outliers
%Xbad=Xcol(Ibad); 
%Ybad=Ycol(Ibad);
% coordinates of the good vectors
Xgood=Xcol(Igood);
Ygood=Ycol(Igood);
% good velocities
Uvalcol=u(:);
Vvalcol=v(:);
Ugood=Uvalcol(Igood);
Vgood=Vvalcol(Igood);
% refill of the outliers
Urefill=griddata(Xgood,Ygood,Ugood,Xcol,Ycol,'linear');
Vrefill=griddata(Xgood,Ygood,Vgood,Xcol,Ycol,'linear');
Uvalcol(Ibad)=Urefill(Ibad);
Vvalcol(Ibad)=Vrefill(Ibad);
% validated vectors 
uf=reshape(Uvalcol,size(u));
vf=reshape(Vvalcol,size(v));
