function [uregr] = space_regression_func(u,N)
% 2nd order spatial regression
% u: 2d matrix;
% N: kernel size (NxN)

r=(N-1)/2;
[X Y]=meshgrid(-r:r,-r:r);
[J,I]=size(u);
uregr=u;
for j=1:J
    jmin=max(1,j-r); jmax=min(J,j+r);
    for i=1:I
        imin=max(1,i-r); imax=min(I,i+r);
        x=X(r+1-(j-jmin):r+1+(jmax-j),r+1-(i-imin):r+1+(imax-i));
        y=Y(r+1-(j-jmin):r+1+(jmax-j),r+1-(i-imin):r+1+(imax-i));
        uloc=u(jmin:jmax,imin:imax);
        uregr(j,i)=regression_solve(uloc,x,y);
        %if j==10 x,y,uloc,figure(1),clf,surf(x,y,uloc);  pause; end
    end %for i
end %for j

% r=(N-1)/2;
% [X Y]=meshgrid(-r:r,-r:r);
% [J,I]=size(u);
% uregr=zeros(J*I,1);
% parfor k=1:I*J
%     i=floor((k-1)/J)+1;
%     j=k-J*(i-1);
%     jmin=max(1,j-r); jmax=min(J,j+r);
%     imin=max(1,i-r); imax=min(I,i+r);
%     x=X(r+1-(j-jmin):r+1+(jmax-j),r+1-(i-imin):r+1+(imax-i));
%     y=Y(r+1-(j-jmin):r+1+(jmax-j),r+1-(i-imin):r+1+(imax-i));
%     uloc=u(jmin:jmax,imin:imax);
%     uregr(k)=regression_solve(uloc,x,y);
%     %if j==10 x,y,uloc,figure(1),clf,surf(x,y,uloc);  pause; end
% end %parfor
% uregr=reshape(uregr,J,I);
% end %end function

