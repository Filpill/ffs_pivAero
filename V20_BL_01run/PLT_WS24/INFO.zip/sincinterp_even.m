function Ao=sincinterp_even(A,denseX,denseY,rad)
warning off all;

% transform to double
A      = double(A);
rad    = double(rad);
% denseX = double(denseX);
% denseY = double(denseY);
denseX = double(denseX);
denseY = double(denseY);
denseXfl = floor(denseX);
denseYfl = floor(denseY);
radm=rad-1; radp=rad;
% initialize variables
[Row,Col] = size(A);
Ao        = zeros(Row,Col);
if std(A(:))==0; 
    Ao=A;
else
    % Calculate new intensities
    for i=1:Row*Col
        % nearest pixel location
%         xn_a = floor(denseX(i));
%         yn_a = floor(denseY(i));
        xn_a = denseXfl(i);
        yn_a = denseYfl(i);
        
        % extensions of stencil
        rad1 = xn_a-radm; if (rad1<1)   rad1=1;   end;
        rad2 = xn_a+radp; if (rad2>Col) rad2=Col; end;
        rad3 = yn_a-radm; if (rad3<1)   rad3=1;   end;
        rad4 = yn_a+radp; if (rad4>Row) rad4=Row; end;
        %rad1:rad2, denseX(i), pause
        % walk over stencil
        buf_a = 0;
        for k=rad1:rad2
            dx_a	= (k-denseX(i))*pi;
            colind2 = ((k-1)*Row);
            if (dx_a==0) sincx_a=1; else sincx_a = sin(dx_a)/(dx_a); end
            
            for m=rad3:rad4
                dy_a   = (m-denseY(i))*pi;
                if (dy_a==0) sincy_a=1; else sincy_a= sin(dy_a)/(dy_a); end
                buf_a = buf_a + (sincx_a*sincy_a*A(m + colind2));
            end %of for m
        end %of for k
        
        % put new values in matrix
        Ao(i) =buf_a;
    end
end
