function [black]=blackman2D(N)
%% routine that computes the 2D Blackman window
% b=(blackman(N)-0.42)/2;
% 
% costot=num2cell(b);        % trasformation of the cosine functions into cells
% 
% c=cell(N); 
% for i=1:N
%     c(i,:)=costot;
% end
% 
% cm=cell2mat(c);     %matrix
% 
% blackold=0.42+cm+cm'; %blackman function

%% new routine
[X Y]=meshgrid(-(N-1)/2:(N-1)/2,-(N-1)/2:(N-1)/2);
[~, r]=cart2pol(X,Y);
R=max(r(:));
alpha=0.16; a0=(1-alpha)/2; a1=1/2; a2=alpha/2;
r2=(R-r)/2;
black=a0-a1*cos(2*pi*r2/R)+a2*cos(4*pi*r2/R);% figure,imagesc(black), axis equal, axis tight, pause
