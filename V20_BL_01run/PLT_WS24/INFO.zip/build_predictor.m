function densepred=build_predictor(grdxold,grdyold,displ,dimx,dimy) %iter,densepredold

% initialize densepred

densepred=zeros(grdyold(end),grdxold(end));

% if iter==1
%     [X,Y]=meshgrid(grdxold,grdyold);
%     [XI,YI]=meshgrid(1:dimx,1:dimy);
%     
%     densepred=(interp2(X,Y,displ,XI,YI,'*linear'));
%     densepred(find(isnan(densepred)))=0;
% else
[X,Y]=meshgrid(grdxold,grdyold);

xin=grdxold(1);
xfin=grdxold(end);
yin=grdyold(1);
yfin=grdyold(end);

%If percentage of D is < 50% or iteration number is < mask iteration value then make denspred for whole image, else apply mask setting old values in D.
[Yline,Xline]=find(ones(dimy,dimx));

%densepred=densepredold;
densepredline=(interp2(X,Y,displ,Xline,Yline,'*linear'));
bufdensepred=densepred(:);
bufdensepred(Yline+(dimy*(Xline-1)))=densepredline;
densepred=reshape(bufdensepred,dimy,dimx);

%(yin:yfin,xin:xfin)
%Left boundary
tmp2=densepred(yin,:);
densepred(1:yin-1,:)=tmp2(  ones( length(1:yin-1),1 ),:  );
%Right boundary
tmp2=densepred(yfin,:);
densepred(yfin+1:dimy,:)=tmp2(  ones( length(yfin+1:dimy),1 ) ,:  );
%Upper boundary
tmp2=densepred(:,xin)';
densepred(:,1:xin-1)=tmp2(  ones( length(1:xin-1),1 ) ,:  )';
%Lower boundary
tmp2=densepred(:,xfin)';
densepred(:,xfin+1:dimx)=tmp2(  ones( length(xfin+1:dimx),1 ) ,:  )';
%Take out NaN's
densepred(find(isnan(densepred)))=0;

% end

%contourf(XI,YI,densepred), colorbar


