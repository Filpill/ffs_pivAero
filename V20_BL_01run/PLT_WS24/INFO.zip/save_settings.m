function save_settings(foldw,fileappw,first,last,Y,X,xregion,yregion,wstot,ovlaptot,itermaxtot,dt)
%save the settings of PIV processing (number of images,window size, overlap, iterations)
zip([foldw 'INFO.zip'],{'*.m'});

settw='Settings';
fid1=fopen([foldw settw fileappw],'w');
fprintf(fid1,'%s\n','*** WIDIM ***');
fprintf(fid1,'%s\n',' ');
fprintf(fid1,'%s\n',['Results in: ' foldw]);
fprintf(fid1,'%s\n',['Matlab file: ' cd '\' mfilename '.m']);
fprintf(fid1,'%s\n',' ');
fprintf(fid1,'%s\n',['Images from ' num2str(first) ' to ' num2str(last) ' (' num2str(last-first) ' velocity fields)']);
fprintf(fid1,'%s\n',['Vector pitch: ' num2str(abs(Y(2)-Y(1))) ' pix']);
fprintf(fid1,'%s\n',['FOV: ' num2str(max(X(:))-min(X(:))+1) 'x' num2str(max(Y(:))-min(Y(:))+1) ' pix2']);
fprintf(fid1,'%s\n',['xregion = ' num2str(xregion)]);
fprintf(fid1,'%s\n',['yregion = ' num2str(yregion)]);
fprintf(fid1,'%s\n',['dt = ' num2str(dt)]);
fprintf(fid1,'%s\n',' ');
fprintf(fid1,'%s\n',' ');
for i=1:length(wstot)
    wsstr=num2str(wstot(i),2);
    ovstr=num2str(ovlaptot(i)*100);
    iterstr=num2str(itermaxtot(i));
    istr=num2str(i,1); 
    fprintf(fid1,'%s\n',[istr ') window ' wsstr 'x' wsstr ' pixels, ' ovstr '% overlap,', ' ' iterstr ' iterations']);
end
fclose(fid1);

end

