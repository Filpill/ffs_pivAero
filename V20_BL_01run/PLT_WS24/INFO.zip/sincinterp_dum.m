function buf_a = sincinterp_dum( rad1,rad2,rad3,rad4,A,dX,dY,Row)
%SINCINTERP_DUM Summary of this function goes here
%   Detailed explanation goes here

 % walk over stencil
        buf_a = 0;
        for k=rad1:rad2
            dx_a	= (k-dX)*pi;
            colind2 = ((k-1)*Row);
            if (dx_a==0) sincx_a=1; else sincx_a = sin(dx_a)/(dx_a); end
            
            for m=rad3:rad4
                %dy_a   = (m-denseY(i))*pi;
                dy_a   = (m-dY)*pi;
                if (dy_a==0) sincy_a=1; else sincy_a= sin(dy_a)/(dy_a); end
                buf_a = buf_a + (sincx_a*sincy_a*A(m + colind2));
            end %of for m
        end %of for k
        
end

