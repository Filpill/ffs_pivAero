function Ao=sincinterp2(A,denseX,denseY,rad)
warning off all;

% transform to double
A      = double(A);
rad    = double(rad);
% denseX = double(denseX);
% denseY = double(denseY);
denseX = double(denseX);
denseY = double(denseY);
denseXfl = floor(denseX);
denseYfl = floor(denseY);

% initialize variables
[Row,Col] = size(A);
Ao        = zeros(Row,Col);
if std(A(:))==0; 
    Ao=A;
else
    % Calculate new intensities
    parfor i=1:Row*Col
        % nearest pixel location
%         xn_a = floor(denseX(i));
%         yn_a = floor(denseY(i));
        xn_a = denseXfl(i);
        yn_a = denseYfl(i);
        dY=denseY(i); dX=denseX(i);
        % extensions of stencil
        rad1 = xn_a-rad; if (rad1<1)   rad1=1;   end;
        rad2 = xn_a+rad; if (rad2>Col) rad2=Col; end;
        rad3 = yn_a-rad; if (rad3<1)   rad3=1;   end;
        rad4 = yn_a+rad; if (rad4>Row) rad4=Row; end;
        
        buf_a = sincinterp_dum( rad1,rad2,rad3,rad4,A,dX,dY,Row);
        
        % put new values in matrix
        Ao(i) =buf_a;
    end
end
