% Subtract Min

folder = 'C:\Users\sbgd290\Desktop\Step\V20_front_01run\RawData\';

% mkdir = 'C:\Users\sbgd290\Desktop\Step\V20_front_01run\Analysis\Subtraction\';

folder_out = 'C:\Users\sbgd290\Desktop\Step\V20_front_01run\Analysis\';
fileroot = 'V20_front_01run';
filetype_a =  '.T000.D000.P000.H000.LA.tif';
filetype_b =  '.T000.D000.P000.H000.LB.tif';


a_min = imread([folder_out 'min_LA.tif']);
b_min = imread([folder_out 'min_LB.tif']);

a = 0;
b = 0;
for inum = 1:20

    inum
    
    filename_a = [folder_out fileroot num2str(inum,'%.6d') filetype_a];
    filename_b = [folder_out fileroot num2str(inum,'%.6d') filetype_b];    
    
    a= a+ imread(filename_a)-400;
    b= b+ imread(filename_b)-400; 


    
end

filetype_a =  '.T002.D000.P000.H000.LA.tif';
filetype_b =  '.T002.D000.P000.H000.LB.tif';


    imwrite(a-a_min,[folder_out fileroot num2str(inum,'%.6d') filetype_a]);
    imwrite(b-b_min,[folder_out fileroot num2str(inum,'%.6d') filetype_b]);
    
