function [g]=gaussian2Dold(Ny,Nx)
if nargin<2, Nx=Ny; end
% 2D gaussian function
[X Y]=meshgrid(-(Nx-1)/2:(Nx-1)/2,-(Ny-1)/2:(Ny-1)/2);
[~, r]=cart2pol(X,Y);
r2=r/max(r(:))*2;
g=exp(-0.5*(r2).^2);
end %end function