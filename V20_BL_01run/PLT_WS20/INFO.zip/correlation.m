function corrmap=correlation(a2,b2,wsx,wsy,radx,rady)

%function [c] = cross_correlate(a2,b2,Nfft)
% CROSS_CORRELATE - calculates the cross-correlation
% matrix of two interrogation areas: 'a2' and 'b2' using
% IFFT(FFT.*Conj(FFT)) method.
% Modified version of 'xcorrf.m' function from ftp.mathworks.com
% site.
% Authors: Alex Liberzon & Roi Gurka

%a2,b2: windows
%corrmap=zeros(wsy,wsx);

%if (std(a2(:))*std(b2(:))>0) %i.e. one of the windows is not completely null
    
    % Rotate the second image ( = conjugate FFT)
    b2 = b2(end:-1:1,end:-1:1);
    
    %For fast FFT Nfft needs to be close to 2^N but smaller, e.g. wsx=15,31,63
    Nfft=2^( ceil(log2(wsx)) );
    %Nffty=2^( ceil(log2(wsy)) );
    
    % FFT of both:
    ffta=fft2(a2,Nfft,Nfft);
    fftb=fft2(b2,Nfft,Nfft);
    
    % Real part of an Inverse FFT of a conjugate multiplication and normalize:
%     c = real(ifft2(ffta.*fftb))/(wsx*wsy);
    c = real(ifft2(ffta.*fftb));
    a2=a2(:); b2=b2(:); s1=sum(a2.^2); s2=sum(b2.^2);
    c=c/sqrt(s1*s2);
    corrmap2=circshift(c,[-radx -rady]);
    corrmap=corrmap2(1:wsy,1:wsx);

%end

