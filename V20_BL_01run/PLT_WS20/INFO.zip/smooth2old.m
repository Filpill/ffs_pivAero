function matrixOut = smooth2(matrixIn, Nr, Nc)

% SMOOTH2.M: Smooths matrix data.
%			MATRIXOUT=SMOOTH2(MATRIXIN,Nr,Nc) smooths the data in MATRIXIN 
%           using a running mean over 2*N+1 successive points, N points on 
%           each side of the current point.  At the ends of the series 
%           skewed or one-sided means are used.  
%
%           Inputs: matrixIn - original matrix
%                   Nr - number of points used to smooth rows
%                   Nc - number of points to smooth columns
%           Outputs:matrixOut - smoothed version of original matrix
%
%           Remark: By default, if Nc is omitted, Nc = Nr.
%
%           Written by Andrea Sciacchitano, October 2011
%           Aerodynamics Department
%           Delft University of Technology



%Initial error statements and definitions
if nargin<2, error('Not enough input arguments'), end

N(1) = Nr; 
if nargin<3 
    N(2) = N(1); 
    Nc=Nr;
else
    N(2) = Nc;
end

if length(N(1))~=1, error('Nr must be a scalar'), end
if length(N(2))~=1, error('Nc must be a scalar'), end

% smoothing
[J I]=size(matrixIn);
% rim construction
Jr=J+2*(Nr-1); Ir=I+2*(Nc-1);
matrixIn2=zeros(Jr,Ir);
matrixIn2(Nr:end-Nr+1,Nc:end-Nc+1)=matrixIn;
[Xr Yr]=meshgrid(1:Ir,1:Jr);
z=find(matrixIn2==0); nz=find(matrixIn2~=0);
matrixIn2(z)=griddata(Xr(nz),Yr(nz),matrixIn2(nz),Xr(z),Yr(z),'nearest');

filt=zeros(size(matrixIn2));
[X Y]=meshgrid(-(Nc-1)/2:(Nc-1)/2,-(Nr-1)/2:(Nr-1)/2);
[~, r]=cart2pol(X,Y);
R=max(r(:));
gaussfilt=exp(-0.5*(r/R*2).^2*1.5^2);

if (mod(I,2)==1 && mod(J,2)==1)
    cJ=(Jr+1)/2; cI=(Ir+1)/2; rj=(Nr-1)/2; ri=(Nc-1)/2;
    filt(cJ-rj:cJ+rj,cI-ri:cI+ri)=gaussfilt/sum(gaussfilt(:));
    Mf=ifft2(fft2(filt).*fft2(matrixIn2));
    matrixOut=circshift(Mf,[cJ,cI]);
else 
    cJ=(Jr)/2; cI=(Ir)/2; rj=(Nr-1)/2; ri=(Nc-1)/2;
    filt(cJ-rj:cJ+rj,cI-ri:cI+ri)=gaussfilt/sum(gaussfilt(:));
    Mf=ifft2(fft2(filt).*fft2(matrixIn2));
    matrixOut=circshift(Mf,[cJ+1,cI+1]);
end
matrixOut=matrixOut(Nr:end-Nr+1,Nc:end-Nc+1);

