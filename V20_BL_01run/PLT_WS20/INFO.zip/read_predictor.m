function [displ grdx grdy] = read_predictor(foldpred,fileroot,field,fileapp)
% function that reads a predictor
zerostr='0000';
fieldstr=num2str(field);
fid=fopen([foldpred fileroot zerostr(1:end-length(fieldstr)) fieldstr fileapp]); %read the file
for i=1:3 tline = fgetl(fid); end
equalsign = findstr(tline, '=');
commasign = findstr(tline, ',');
leny=str2num(tline(equalsign(2)+1:commasign(2)-1));
lenx=str2num(tline(equalsign(3)+1:end));
M=textscan(fid, '%f %f %f %f %f %f %f');
M=[M{1} M{2} M{3} M{4}];
fclose(fid);
X=reshape(M(:,1),leny,lenx);
Y=reshape(M(:,2),leny,lenx);
u=reshape(M(:,3),leny,lenx);
v=reshape(M(:,4),leny,lenx);
displ=cat(3,u,v);
grdx=X(1,:);
grdy=Y(:,1);
grdy=(flipud(grdy))';
end % end function

