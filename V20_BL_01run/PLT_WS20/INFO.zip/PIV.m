clc
clear
close all
warning off

if matlabpool('size')==0
    matlabpool;
end

tic
%% Routine that performs the PIV of images in continuous mode through the
% conventional PIV (snapshots correlation)

%the routine uses the matlabpool and the parfor to be faster
%% data
first=1;        %first image to be read
last=500;       %last image to be read
dt=1;           %time between the snapshots
weight='gaussian';    % 'tophat', 'gaussian' or 'blackman';

maskflag='no'; %yes or no
xmask=[244 244 482 482];
ymask=[264 264 196 196];
% xmask=[1 310 1];
% ymask=[88 129 179];

% reading folder and files
%foldread=['K:\jet5457\'];
foldread=['F:\FYP2016\Step\V20_BL_01run\RawData\Sub\Smooth\'];
fileroot='V20_BL_01run';

% fileroot_a='LA_';
% fileroot_b='LB';
% fileapp='.tif';
fileapp_a='.T000.D000.P000.H000.LA.TIF';
fileapp_b='.T000.D000.P000.H000.LB.TIF';
% fileapp_a='.TIF';
% fileapp_b='.TIF';

% writing folder and files
%foldw=['F:\andrea\uncertainty estimation\data\jet_tot\WIDIM\ws33\jet5457\'];
foldw=['F:\FYP2016\Step\V20_BL_01run\PLT_WS20\'];
filew='B0';
fileappw='.plt';

%% windows parameters
% parameters first window
wstot(1)=96;        % window size [pix], first window
ovlaptot(1)=0.5;    % overlap [between 0 and 1], first window
itermaxtot(1)=1;    % number of iterations, first window 

wstot(2)=64;        % window size [pix], first window
ovlaptot(2)=0.5;    % overlap [between 0 and 1], first window
itermaxtot(2)=1;    % number of iterations, first window 

wstot(3)=48;        % window size [pix], first window
ovlaptot(3)=0.5;    % overlap [between 0 and 1], first window
itermaxtot(3)=2;    % number of iterations, first window 

wstot(4)=32;        % window size [pix], first window
ovlaptot(4)=0.5;    % overlap [between 0 and 1], first window
itermaxtot(4)=2;    % number of iterations, first window 

wstot(5)=20;        % window size [pix], first window
ovlaptot(5)=0.5;    % overlap [between 0 and 1], first window
itermaxtot(5)=2;    % number of iterations, first window 


xregion=[1 1280];  % [pix]
yregion=[1 800];   % [pix]
%binned
% xregion=[137 777]; xregion=floor(xregion/2);  % [pix]
% yregion=[10 1605]; yregion=floor(yregion/2);  % [pix]

%% create the folder foldw (where the data are written) if it doesn't exist
if exist(foldw,'dir')~=7
    mkdir(foldw);
end
zip([foldw 'INFO.zip'],{'PIV.m'})

%% inizialization
countim=0;
zerostr='000000';
firststr=num2str(first);
im{1,2}=double(imread([foldread fileroot zerostr(1:end-length(firststr)) firststr fileapp_a], 'PixelRegion', {yregion, xregion}));
I=size(im{1,2},2);              % number of columns in the image
J=size(im{1,2},1);              % number of rows in the image
ntot=(last-first+1);            % total number of images to be read
ntotstr=num2str(last-first+1);  % total number of velocity fields to compute (string)

%% plot of the first image
if strcmp(maskflag,'yes') maskcoeff=0; else maskcoeff=999999; end
xmask=xmask+maskcoeff;
ymask=J-ymask;
clc

%% Loop on the images
for nim=first:last
    countim=countim+1;
    
    nimstr=num2str(nim);
    filename=[foldread fileroot zerostr(1:end-length(nimstr)) nimstr fileapp_a];
    im{1,1}=double(imread(filename, 'PixelRegion', {yregion, xregion}));
    
    nimstr=num2str(nim);
    filename=[foldread fileroot zerostr(1:end-length(nimstr)) nimstr fileapp_b];
    im{1,2}=double(imread(filename, 'PixelRegion', {yregion, xregion}));
    
    %im{1}=im{1}+20*randn(400,400); im{2}=im{2}+20*randn(400,400);
    disp(' ')
    disp(['processing velocity field ' num2str(countim) ' of ' ntotstr])
    disp(' ')


%% loop on the window sizes from first to final
    for nws=1:length(wstot) 
        ws=wstot(nws);
        r=floor((ws-1)/2);
        wsstr=num2str(ws,3);
        ovlap=ovlaptot(nws);
        ovstr=num2str(ovlap*100);
        itermax=itermaxtot(nws);
        disp(['window ' wsstr 'x' wsstr ' pixels, ' ovstr '% overlap']);
        
        step=round(ws-ovlap*ws);
        grdx=max(round((step-1)/2),1):step:I;         % x-coordinate of grid
        lenx=length(grdx);                            % x-nr. of grid
        grdy=max(round((step-1)/2),1):step:J;         % y-ciirdinate of grid
        leny=length(grdy);                            % y-nr. of grid
        
        mask=flipud(abs(poly2mask(xmask/step,ymask/step,leny,lenx)-ones(leny,lenx)));      %zero inside the mask, one outside
        [X Y]=meshgrid(grdx,grdy);                    % setup the grid for the vector field
        Y=flipud(Y);                                  % flip y-axis start from bottom-left, before this started from top-left
        Xsave=X';
        Ysave=Y';
        if strcmp(weight,'tophat')
            ws2=ws; black=ones(ws2);
        elseif strcmp(weight,'gaussian')
            ws2=floor(ws*1.4); if mod(ws2,2)==0, ws2=ws2+1; end
            black=gaussian2Dold(ws2);
        elseif strcmp(weight,'blackman')
            ws2=floor(ws*1.8); if mod(ws2,2)==0, ws2=ws2+1; end
            black=blackman2D(ws2);
        else
            error('"weight" has to be "tophat", "gaussian" or "blackman"')
        end
        r2=(ws2-1)/2;
        %grdxold=grdx; grdyold=grdy;
        %if (nws==1) displ=zeros(leny,lenx,2); displ(:,:,1)=displ(:,:,1)+4*dt; end  %initialization of the displacement
        if (nws==1) displ=zeros(leny,lenx,2); end       %initialization of the displacement
%% main iteration loop
        iter=1;


        while (iter<=itermax)                           % iter: number of iteration
            fprintf(['iteration ' num2str(iter)])
            lastiter=0;

            if (norm(squeeze(displ(:,:,1)))+norm(squeeze(displ(:,:,2)))>0) %it's not the first iteration
                xtransf=cell(1,2);
                ytransf=cell(1,2);
                displold=displ;
                clear displ

                % predictor
                fprintf(' - Predictor building');
                densepred(:,:,1)=build_predictor(grdxold,grdyold,displold(:,:,1),I,J);	% dense predictor x
                densepred(:,:,2)=build_predictor(grdxold,grdyold,displold(:,:,2),I,J);	% dense predictor y
                

                [tmpx,tmpy]=meshgrid(1:I,1:J);
                
                % displacement to be imposed to the two images
                xtransf{1,1}=tmpx - 0.5*densepred(:,:,1);
                xtransf{1,2}=tmpx + 0.5*densepred(:,:,1);
                ytransf{1,1}=tmpy - 0.5*densepred(:,:,2);
                ytransf{1,2}=tmpy + 0.5*densepred(:,:,2);
                clear tmpx tmpy
                
                diff_disp=zeros(leny,lenx);
                lmin=min(length(grdx),length(grdxold));
                if (length(grdx)~=length(grdxold) || norm(grdx(1:lmin)-grdxold(1:lmin))>0)
                    diff_disp(:,:,1)=interp2(Xold,Yold,displold(:,:,1),X,Y,'*spline');
                    diff_disp(:,:,2)=interp2(Xold,Yold,displold(:,:,2),X,Y,'*spline');
                else
                    diff_disp=displold;
                end

                clear densepred

                % distortion (sinc interpolation for the images, based on the predictor)
                fprintf(' - Image interpolation');
                imsinc=cell(1,2);               
                
                parfor h=1:2
                    imsinc{h}=sincinterp_even(im{1,h},xtransf{1,h},ytransf{1,h},3);
                end
                clear xtransf ytransf
                
            else %iter==1 (no image interpolation needed)
                imsinc=im;
                diff_disp=zeros(leny,lenx,2);           
            end %if iter>1
            
            if (ws==wstot(end) && iter==itermaxtot(end))
                lastiter=1;
            end
            
            fprintf(' - Cross correlation');
            snbuf=zeros(lenx*leny,1);
            displ1=zeros(lenx*leny,1);
            displ2=zeros(lenx*leny,1);
            Rbuf=cell(lenx*leny,1);
            parfor k=1:lenx*leny               % loop on the columns
                if mask(k)==1 %outside the mask
                iwin=floor((k-1)/leny)+1;   % X-index of window
                jwin=k-leny*(iwin-1);       % Y-index of window          
                        window=cell(1,2);
                        for h=1:2
                            window{h}=build_window(imsinc{h},grdx(iwin),grdy(jwin),ws2,ws2,r2,r2).*black;   % Extract the window
                        end
                        subcorrmap = correlation(window{2},window{1},ws2,ws2,r2,r2);                        % Correlation
                                      
                        [peaks,sn]=analyse_map82(subcorrmap);              % Return peaks position and peak ratio
                        if (lastiter==1)
                            snbuf(k)=sn;
                            Rbuf{k}=subcorrmap;
                        end
                        if norm(peaks(1,:))>0
                            [displx,disply]=gaussian(peaks,subcorrmap);
                        else displx=0; disply=0; 
                        end
                        displ1(k)=displx;
                        displ2(k)=disply;
                        
                end %if mask
            end %parfor k
            R=reshape(Rbuf,leny,lenx);
            %Rtot{countim}=R{floor(leny/2),floor(lenx/3)};
            %Rtot{countim}=R{20,19};


            %clear corrmap
            
            %%%%%%%% outliers detection and refill %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            fprintf(' - Outliers detection and refill\n');
            displ12=vertcat(displ1,displ2);
            displ=reshape(displ12,leny,lenx,2);
            outThr=2;       %threshold for detecting the outliers
            displ1old=displ(:,:,1); displ2old=displ(:,:,2); flagout=zeros(leny,lenx);
            [displ(:,:,1),displ(:,:,2)] = outliers2(outThr,displ(:,:,1),displ(:,:,2),X,Y);        % filtered displacements (outliers removed)
            displ(isnan(displ))=0;
            flagout((displ(:,:,1)-displ1old)~=0 | (displ(:,:,2)-displ2old)~=0)=1;
            
            %update the displacement field
            displ=displ+diff_disp;
            [displ(:,:,1),displ(:,:,2)] = outliers2(outThr,displ(:,:,1),displ(:,:,2),X,Y);        % filtered displacements (outliers removed)
            displ(isnan(displ))=0;
            
            if (iter~=itermax || nws<length(wstot))
%                 displ(:,:,1)=smooth2(displ(:,:,1),3);
%                 displ(:,:,2)=smooth2(displ(:,:,2),3);
                displ(:,:,1)=space_regression_func(displ(:,:,1),5);
                displ(:,:,2)=space_regression_func(displ(:,:,2),5);
            end
            
            iter=iter+1;
            grdxold=grdx;
            grdyold=grdy;
            Xold=X; Yold=Y;
        end %while iter<itermax
    end %loop on the window sizes
    figure,imagesc(Rbuf{5}), axis equal, axis tight, caxis([-0.1 1])
    
    if (countim==1 && nws==length(wstot) && iter==itermax) %initialization of the displacement fields
        displutot=zeros(size(displ,1),size(displ,2),ntot-1);
        displvtot=zeros(size(displ,1),size(displ,2),ntot-1);
        sntot=zeros(size(displ,1),size(displ,2),ntot-1);
        %corrmap=cell(size(displ,1),size(displ,2),ntot-1);
    end
    
    displutot(:,:,countim)=(displ(:,:,1));
    displvtot(:,:,countim)=-(displ(:,:,2));
    sntot(:,:,countim)=reshape(snbuf,leny,lenx);
    
%% save the velocity fields, in the order: X, Y, u, v, sn
    
    fprintf('Saving the data \n');
    
    %yoff=(1589-max(Ysave(:))-(yregion(1)-10)); %*****************************
    
    filename=[filew makestr(nim) num2str(nim)];
    u=displutot(:,:,countim)';
    u=u(:);
    v=displvtot(:,:,countim)';
    v=v(:);
    snw=sntot(:,:,countim')';
    snw=snw(:);
    savematrix=[Xsave(:) Ysave(:) u./dt v./dt snw];
%     savematrix=[(2*Xsave(:)-1) (2*Ysave(:)-1) u./dt*2 v./dt*2 snw]; %binned
    
    fid=fopen([foldw filename fileappw],'w');
    fprintf(fid,'%s\n',['TITLE = "' filename '"']);
    fprintf(fid,'%s\n','VARIABLES = "x", "y", "u", "v", "sn"');
    fprintf(fid,'%s\n',['ZONE T="Frame 0", I=' num2str(size(X,2)) ', J=' num2str(size(X,1))]);
    fprintf(fid,'%u %u %.6f %.6f %.3f \n',savematrix');
    fclose(fid);
    toc
    
    if countim==1
        ut1=u; vt1=v;
    end
    close all;
end %loop on the images



% save the settings
save_settings(foldw,fileappw,first,last,Y,X,xregion,yregion,wstot,ovlaptot,itermaxtot,dt)
% 
% [Xs Ys]=meshgrid(-8:8,-8:8);
% c=R{22,26};
% savematrix=[Xs(:) Ys(:) c(:)];
% fid=fopen([foldw 'C' fileappw],'w');
% fprintf(fid,'%s\n',['TITLE = "C"']);
% fprintf(fid,'%s\n','VARIABLES = "x", "y", "C"');
% fprintf(fid,'%s\n',['ZONE T="Frame 0", I=' num2str(size(Xs,1)) ', J=' num2str(size(Xs,2))]);
% fprintf(fid,'%4u\t %4u\t %4.5f\t\n',savematrix');
% fclose(fid);

toc